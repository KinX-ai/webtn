<?php
// Database configuration
$host = 'localhost';
$dbname = 'meta_testorr';
$username = 'meta_testorr';
$password = 'testorr';
