<?php
// Set max execution time to 5 minutes for large imports
ini_set('max_execution_time', 300);
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Get database connection parameters from form
$host = $_POST['db_host'] ?? 'localhost';
$dbname = $_POST['db_name'] ?? '';
$username = $_POST['db_user'] ?? ''; 
$password = $_POST['db_pass'] ?? '';

// Initialize variables
$error = '';
$success = '';
$admin_username = 'admin';
$admin_password = 'Admin@123';
$admin_email = 'admin@example.com';

// Process setup form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    try {
        // Connect to MySQL server without selecting database
        $pdo = new PDO("mysql:host=$host", $username, $password);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Create database with utf8mb4
        $pdo->exec("DROP DATABASE IF EXISTS `$dbname`");
        $pdo->exec("CREATE DATABASE `$dbname` CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci");
        $pdo->exec("USE `$dbname`");

        // Create tables
        $queries = [
            "CREATE TABLE `fb_account_types` (
                `id` int NOT NULL AUTO_INCREMENT,
                `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
                `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (`id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

            "CREATE TABLE `fb_sources` (
                `id` int NOT NULL AUTO_INCREMENT,
                `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
                `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
                `status` enum('active','inactive') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
                PRIMARY KEY (`id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

            "CREATE TABLE `users` (
                `id` int NOT NULL AUTO_INCREMENT,
                `username` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
                `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
                `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
                `role` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
                `created_at` timestamp NOT NULL,
                `status` tinyint NOT NULL DEFAULT '1',
                `parent_id` int DEFAULT NULL,
                `avatar` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
                PRIMARY KEY (`id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci",

            "CREATE TABLE `fb_configs` (
                `id` int NOT NULL AUTO_INCREMENT,
                `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
                `account_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
                `source` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
                `account_type_id` int NOT NULL,
                `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (`id`),
                KEY `account_type_id` (`account_type_id`),
                CONSTRAINT `fb_configs_ibfk_1` FOREIGN KEY (`account_type_id`) REFERENCES `fb_account_types` (`id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

            "CREATE TABLE `fb_orders` (
                `id` int NOT NULL AUTO_INCREMENT,
                `user_id` int NOT NULL,
                `fb_config_id` int NOT NULL,
                `quantity` int NOT NULL,
                `source` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
                `status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Pending',
                `notification` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
                `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (`id`),
                KEY `fb_config_id` (`fb_config_id`),
                KEY `user_id` (`user_id`),
                CONSTRAINT `fb_orders_ibfk_1` FOREIGN KEY (`fb_config_id`) REFERENCES `fb_configs` (`id`),
                CONSTRAINT `fb_orders_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

            "CREATE TABLE `logs` (
                `id` int NOT NULL AUTO_INCREMENT,
                `user_id` int NOT NULL,
                `action` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
                `details` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
                `created_at` timestamp NOT NULL,
                PRIMARY KEY (`id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci",

            "CREATE TABLE `orders` (
                `id` int NOT NULL AUTO_INCREMENT,
                `user_id` int NOT NULL,
                `resource_type` int NOT NULL,
                `quantity` int NOT NULL,
                `source` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
                `status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'Pending',
                `created_at` timestamp NOT NULL,
                `price` decimal(10,2) DEFAULT NULL,
                `notification` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
                PRIMARY KEY (`id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci",

            "CREATE TABLE `resource_types` (
                `id` int NOT NULL AUTO_INCREMENT,
                `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
                PRIMARY KEY (`id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci"
        ];

        foreach ($queries as $query) {
            $pdo->exec($query);
        }

        // Create admin account
        $admin_hash = password_hash($admin_password, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("INSERT INTO users (username, password, email, role, created_at, status) VALUES (?, ?, ?, 'ADMIN', NOW(), 1)");
        $stmt->execute([$admin_username, $admin_hash, $admin_email]);

        // Create config file
        $config_content = "<?php
// Database configuration
\$host = '$host';
\$dbname = '$dbname';
\$username = '$username';
\$password = '$password';
";
        file_put_contents('includes/config.php', $config_content);

        $success = "Thiết lập cơ sở dữ liệu thành công. Tài khoản admin đã được tạo:<br>
                   Tài khoản: $admin_username<br>
                   Mật khẩu: $admin_password";

    } catch(Exception $e) {
        $error = "Lỗi: " . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thiết lập HKD Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            background-color: #f5f5f5;
            padding-top: 40px;
            padding-bottom: 40px;
        }
        .setup-container {
            max-width: 600px;
            margin: 0 auto;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            padding: 30px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="setup-container">
            <div class="text-center mb-4">
                <h2>Thiết lập HKD Management</h2>
                <p class="text-muted">Cấu hình cơ sở dữ liệu và tài khoản quản trị viên</p>
            </div>

            <?php if (!empty($error)): ?>
            <div class="alert alert-danger" role="alert">
                <i class="fas fa-exclamation-circle me-2"></i> <?php echo $error; ?>
            </div>
            <?php endif; ?>

            <?php if (!empty($success)): ?>
            <div class="alert alert-success" role="alert">
                <i class="fas fa-check-circle me-2"></i> <?php echo $success; ?>
                <hr>
                <p>Bạn có thể <a href="login.php" class="alert-link">đăng nhập</a> vào hệ thống ngay bây giờ.</p>
            </div>
            <?php else: ?>
            <form method="post" class="setup-form">
                <div class="mb-3">
                    <label class="form-label">Database Host:</label>
                    <input type="text" name="db_host" class="form-control" value="localhost" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Database Name:</label>
                    <input type="text" name="db_name" class="form-control" value="" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Database Username:</label>
                    <input type="text" name="db_user" class="form-control" value="" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Database Password:</label>
                    <input type="password" name="db_pass" class="form-control" value="" required>
                </div>
                <div class="d-grid gap-2">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-cogs me-2"></i> Thiết lập hệ thống
                    </button>
                </div>
            </form>
            <?php endif; ?>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>