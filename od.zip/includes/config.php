<?php
// Database configuration
$host = 'localhost';
$dbname = 'psolutio_order';
$username = 'psolutio_order';
$password = 'psolutio_order';
